# Student Performance Analysis System (Academics + Sports Integration)

A zero-dependency Python console application for batch processing student academic records, weighted athletic metrics, Composite Performance Index (CPI) scoring, profile classification, early risk diagnostics, and CSV reporting.

## Overview

Most student evaluation tools track academic marks separately from physical wellness and extracurricular participation. This project unifies both dimensions into a single deterministic pipeline using only Python's standard library (`csv` and `math`).

## Key Features

- **Strict Data Validation (`DataManager`)**: Verifies required schemas, non-empty strings, unique student IDs, finite numeric values (`0–100`), and CSV column headers/rows.
- **Quantitative Scoring (`StatisticalComputationEngine`)**:
  - **Academic Percentage**: Unweighted mean across academic subjects.
  - **Sports Score**: `0.40 * fitness_score + 0.35 * participation_pct + 0.25 * event_points`
  - **Composite Performance Index (CPI)**: `0.70 * academic_percentage + 0.30 * sports_score`
  - **Letter Grades & Profile Tiers**: Maps scores to grades (`A+` to `F`) and tiers (`Elite All-Rounder`, `Academic Scholar`, `Athletic Prodigy`, `Consistent Performer`, `Development Required`), plus cohort mean and standard deviation.
- **Early Risk Diagnostics (`DiagnosticEngine`)**: Detects `ACADEMIC_FAIL` (`< 40` in any subject), `SPORTS_DISENGAGEMENT` (`participation_pct < 50`), and `WELLNESS_RISK` (`academic_percentage >= 80` with `sports_score < 45`), assigning actionable interventions.
- **Console & CSV Reporting (`ReportExporter`)**: Prints structured summaries to stdout and exports clean CSV reports (`student_report.csv`).

## Project Structure

```text
student-performance-analysis-system/
├── student_performance_system.py   # Core classes & CLI entry point
├── sample_students.csv             # Sample CSV dataset for testing DataManager.load_csv()
├── .gitignore                      # Python ignore rules
└── README.md                       # Project documentation
```

## Getting Started

### Prerequisites
- Python 3.8+ (no external packages required)

### Run the Application
```bash
python student_performance_system.py
```

## Team & Module Ownership

- **Aman Ranjan (Lead)**: Statistical Computation Engine
- **Kumar Anshuman**: Data Management & Input Validation
- **Tanmay Sirohi**: Computational Diagnostic & Remedial Engine
- **Arnav Gupta**: Automated Reporting & File Export
- **Suraj Gaur**: User Interface & Orchestration
