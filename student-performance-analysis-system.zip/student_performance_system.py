import csv
import math


class DataManager:
    @staticmethod
    def check_score(score):
        if isinstance(score, bool) or not isinstance(score, (int, float)):
            raise ValueError("Scores must be numeric.")
        if math.isnan(score) or math.isinf(score):
            raise ValueError("Scores must be finite numbers.")
        if not 0 <= score <= 100:
            raise ValueError("Scores must be between 0 and 100.")

    @staticmethod
    def validate(records):
        if not records:
            raise ValueError("Dataset cannot be empty.")

        ids = set()
        for r in records:
            if not isinstance(r, dict) or not all(
                k in r for k in ("student_id", "name", "academics", "sports")
            ):
                raise ValueError("Missing student data.")

            sid = str(r["student_id"]).strip()
            name = str(r["name"]).strip()
            if not sid or not name:
                raise ValueError("Student ID and name cannot be empty.")

            if sid in ids:
                raise ValueError(f"Duplicate student ID: {sid}")
            ids.add(sid)

            if not isinstance(r["academics"], dict) or not r["academics"]:
                raise ValueError("Academic subjects cannot be empty.")

            for sub, score in r["academics"].items():
                if not str(sub).strip():
                    raise ValueError("Subject name cannot be empty.")
                DataManager.check_score(score)

            s = r["sports"]
            if not isinstance(s, dict) or not all(
                k in s for k in ("sport_name", "fitness_score", "participation_pct", "event_points")
            ):
                raise ValueError("Missing sports data.")

            if not str(s["sport_name"]).strip():
                raise ValueError("Sport name cannot be empty.")

            for k in ("fitness_score", "participation_pct", "event_points"):
                DataManager.check_score(s[k])

    @staticmethod
    def load_csv(filepath):
        records = []
        expected_cols = {
            "student_id", "name", "Mathematics", "Python", "Electronics",
            "sport_name", "fitness_score", "participation_pct", "event_points",
        }
        with open(filepath, "r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValueError("CSV file is empty or missing headers.")
            missing_cols = expected_cols - set(reader.fieldnames)
            if missing_cols:
                raise ValueError(f"Missing expected CSV columns: {sorted(missing_cols)}")

            for row_num, row in enumerate(reader, start=2):
                try:
                    if any(v is None for v in row.values()):
                        raise ValueError("Row has missing or extra columns.")
                    academics = {
                        subj: float(row[subj].strip())
                        for subj in ("Mathematics", "Python", "Electronics")
                    }
                    sports_nums = {
                        metric: float(row[metric].strip())
                        for metric in ("fitness_score", "participation_pct", "event_points")
                    }
                    records.append({
                        "student_id": row["student_id"].strip(),
                        "name": row["name"].strip(),
                        "academics": academics,
                        "sports": {
                            "sport_name": row["sport_name"].strip(),
                            **sports_nums,
                        },
                    })
                except ValueError as e:
                    raise ValueError(f"Invalid data at CSV row {row_num}: {e}") from e

        DataManager.validate(records)
        return records


class StatisticalComputationEngine:
    @staticmethod
    def grade(percentage):
        if percentage >= 90:
            return "A+"
        if percentage >= 80:
            return "A"
        if percentage >= 70:
            return "B"
        if percentage >= 60:
            return "C"
        if percentage >= 40:
            return "D"
        return "F"

    @staticmethod
    def process(r):
        academic = sum(r["academics"].values()) / len(r["academics"])
        s = r["sports"]
        sports = (
            0.40 * s["fitness_score"]
            + 0.35 * s["participation_pct"]
            + 0.25 * s["event_points"]
        )
        cpi = 0.70 * academic + 0.30 * sports

        rounded_academic = round(academic, 2)
        rounded_sports = round(sports, 2)
        rounded_cpi = round(cpi, 2)

        if rounded_academic >= 85 and rounded_sports >= 80:
            tier = "Elite All-Rounder"
        elif rounded_academic >= 85:
            tier = "Academic Scholar"
        elif rounded_sports >= 85:
            tier = "Athletic Prodigy"
        elif rounded_cpi >= 60:
            tier = "Consistent Performer"
        else:
            tier = "Development Required"

        return {
            "student_id": str(r["student_id"]).strip(),
            "name": str(r["name"]).strip(),
            "academic_percentage": rounded_academic,
            "grade": StatisticalComputationEngine.grade(rounded_academic),
            "sport_name": str(s["sport_name"]).strip(),
            "sports_score": rounded_sports,
            "cpi": rounded_cpi,
            "profile_tier": tier,
        }

    @staticmethod
    def summary(results):
        if not results:
            return {
                "students": 0,
                "average_cpi": 0.0,
                "cpi_standard_deviation": 0.0,
            }
        cpis = [r["cpi"] for r in results]
        mean = sum(cpis) / len(cpis)
        sd = math.sqrt(sum((x - mean) ** 2 for x in cpis) / len(cpis))
        return {
            "students": len(results),
            "average_cpi": round(mean, 2),
            "cpi_standard_deviation": round(sd, 2),
        }


class DiagnosticEngine:
    @staticmethod
    def diagnose(raw, result):
        flags, actions = [], []
        failed = [sub for sub, score in raw["academics"].items() if score < 40]
        s = raw["sports"]

        if failed:
            flags.append("ACADEMIC_FAIL")
            actions.append("Tutoring required: " + ", ".join(failed))

        if s["participation_pct"] < 50:
            flags.append("SPORTS_DISENGAGEMENT")
            actions.append("PE counselor check-in")

        if result["academic_percentage"] >= 80 and result["sports_score"] < 45:
            flags.append("WELLNESS_RISK")
            actions.append("Wellness workshops and recreational sports")

        result["flags"] = flags
        result["risk_status"] = "AT_RISK" if flags else "HEALTHY"
        result["interventions"] = actions or ["None"]
        return result


class ReportExporter:
    @staticmethod
    def display(results):
        if not results:
            print("No student records to display.")
            return
        for r in results:
            print(
                f'{r["student_id"]} | {r["name"]} | '
                f'Academic: {r["academic_percentage"]:.2f}% | '
                f'Grade: {r["grade"]} | Sports: {r["sports_score"]:.2f} | '
                f'CPI: {r["cpi"]:.2f} | {r["profile_tier"]} | '
                f'{r["risk_status"]}'
            )
            if r["flags"]:
                print("  Flags:", ", ".join(r["flags"]))
                print("  Actions:", "; ".join(r["interventions"]))

    @staticmethod
    def export_csv(results, filename="student_report.csv"):
        if not filename or not str(filename).strip():
            raise ValueError("Output CSV filename cannot be empty.")
        fields = [
            "student_id", "name", "academic_percentage", "grade",
            "sport_name", "sports_score", "cpi", "profile_tier",
            "risk_status", "flags", "interventions",
        ]
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for r in results:
                row = r.copy()
                row["academic_percentage"] = f'{r["academic_percentage"]:.2f}'
                row["sports_score"] = f'{r["sports_score"]:.2f}'
                row["cpi"] = f'{r["cpi"]:.2f}'
                row["flags"] = (
                    "; ".join(r["flags"])
                    if isinstance(r.get("flags"), list)
                    else str(r.get("flags", ""))
                )
                row["interventions"] = (
                    "; ".join(r["interventions"])
                    if isinstance(r.get("interventions"), list)
                    else str(r.get("interventions", ""))
                )
                writer.writerow(row)


class PerformanceApp:
    def __init__(self, records=None):
        self.records = records if records is not None else [
            {
                "student_id": "ST101", "name": "Aman R.",
                "academics": {"Mathematics": 88, "Python": 90, "Electronics": 86},
                "sports": {"sport_name": "Football", "fitness_score": 85,
                           "participation_pct": 90, "event_points": 80},
            },
            {
                "student_id": "ST102", "name": "Tanmay S.",
                "academics": {"Mathematics": 80, "Python": 82, "Electronics": 80},
                "sports": {"sport_name": "Badminton", "fitness_score": 82,
                           "participation_pct": 85, "event_points": 80.4},
            },
            {
                "student_id": "ST103", "name": "Anshuman K.",
                "academics": {"Mathematics": 90, "Python": 92, "Electronics": 90},
                "sports": {"sport_name": "Athletics", "fitness_score": 55,
                           "participation_pct": 45, "event_points": 48},
            },
            {
                "student_id": "ST104", "name": "Suraj G.",
                "academics": {"Mathematics": 38, "Python": 60, "Electronics": 57},
                "sports": {"sport_name": "Cricket", "fitness_score": 85,
                           "participation_pct": 85, "event_points": 80},
            },
            {
                "student_id": "ST105", "name": "Arnav G.",
                "academics": {"Mathematics": 83, "Python": 85, "Electronics": 82},
                "sports": {"sport_name": "Table Tennis", "fitness_score": 75,
                           "participation_pct": 76, "event_points": 72.8},
            },
        ]

    def run(self):
        DataManager.validate(self.records)
        results = [
            DiagnosticEngine.diagnose(
                raw, StatisticalComputationEngine.process(raw)
            )
            for raw in self.records
        ]
        ReportExporter.display(results)
        print("\nCohort Summary:", StatisticalComputationEngine.summary(results))
        ReportExporter.export_csv(results)
        print("Report saved to student_report.csv")


if __name__ == "__main__":
    try:
        PerformanceApp().run()
    except (ValueError, KeyError, TypeError, OSError) as e:
        print("Error:", e)
